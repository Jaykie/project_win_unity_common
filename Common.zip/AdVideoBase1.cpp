#include "pch.h"
#include "AdVideoBase1.h"
using namespace Common;

AdVideoBase1::AdVideoBase()
{
}

//
//AdVideoBase::~AdVideoBase()
//{
//}

void AdVideoBase1::InitAd(String^ appId,String^ appKey)
{
	//strAppId = appId;
	//strAppKey = appKey;

}

void AdVideoBase1::ShowAd()
{

}
void AdVideoBase1::SetObjectInfo(String^ objName, String^ objMethod)
{

}
 
