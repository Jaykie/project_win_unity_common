#pragma once
#include "Common.h"
using namespace Platform; 
using namespace Windows::UI::Core;

namespace Common
{
	public ref class AdVideoBase1 : public ::Windows::UI::Xaml::Controls::Page
{

internal:
	AdVideoBase1();
//	~AdVideoBase();

internal:
virtual	void InitAd(String^ appId,String^ appKey);
virtual void ShowAd();
virtual	void SetObjectInfo(String^ objName, String^ objMethod);

internal:
	String^ source;
	String^ strAppId;
	String^ strAppKey; 
};
}

